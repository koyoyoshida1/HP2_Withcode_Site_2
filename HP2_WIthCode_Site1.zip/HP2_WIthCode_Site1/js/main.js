'use strict';

//ローディング画面の表示
$(window).on('load',function(){
  $("#loading").delay(2000).fadeOut('slow');
  $("#loading_box").delay(1750).fadeOut('slow');
});

function fadeIn() {
  $('.fadeUpTrigger').each(function () {
    let scroll = $(window).scrollTop();
    let triTop = $(this).offset().top + 100;
    let winHeight = $(window).height();
    if (scroll >= triTop - winHeight) {
      $(this).addClass('fadeUp');
    }
    else {
      $(this).removeClass('fadeUp');
    }
  });
  
  $('.fadeLeftTrigger').each(function () {
    let scroll = $(window).scrollTop();
    let triTop = $(this).offset().top + 100;
    let winHeight = $(window).height();
    if (scroll >= triTop - winHeight){
      $(this).addClass('fadeLeft');
    }
    else {
      $(this).removeClass('fadeLeft');
    }
  });
  
  $('.fadeRightTrigger').each(function () {
    let scroll = $(window).scrollTop();
    let triTop = $(this).offset().top + 100;
    let winHeight = $(window).height();
    if (scroll >= triTop - winHeight){
      $(this).addClass('fadeRight');
    }else{
      $(this).removeClass('fadeRight');
    }
  });
}

$(window).scroll(function () {
  fadeIn();
});

$('.top').addClass('fadeUpTrigger');
$('.intro').addClass('fadeUpTrigger');
$('.btn').addClass('fadeUpTrigger');
$('.section_ttl').addClass('fadeUpTrigger');
$('.breadcrumb').addClass('fadeUpTrigger');
$('.about_item').addClass('fadeUpTrigger');
$('.news_item').addClass('fadeUpTrigger');
$('.footer_item').addClass('fadeUpTrigger');
$('.service_item._service1').addClass('fadeLeftTrigger');
$('.service_item._service3').addClass('fadeLeftTrigger');
$('.service_item._service2').addClass('fadeRightTrigger');
$('.service_item._service4').addClass('fadeRightTrigger');
$('.about_com_item').addClass('fadeUpTrigger');
$('.about_mem_per').addClass('fadeUpTrigger');
$('.about_acc_map').addClass('fadeLeftTrigger');
$('.about_acc_item').addClass('fadeRightTrigger');
$('.contact_item').addClass('fadeUpTrigger');
$('.contact_img').addClass('fadeRightTrigger');
$('.contact_box').addClass('fadeUpTrigger');
$('.contact_box._area').addClass('fadeUpTrigger');
$('.contact_btn').addClass('fadeUpTrigger');
$('.news_item').addClass('fadeUpTrigger');
